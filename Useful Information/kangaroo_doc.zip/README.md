# other random stuff

## current train of thought...

In this thread it looks like someone sent an MB8841 from a Kangaroo board into some people named Smittdog and MogglyGuy, Smittdog sent them in to get decapped back in May of last year...

https://www.mameworld.info/ubbthreads/showflat.php?Cat=&Number=393907&page=&view=&sb=5&o=&vc=1

so where did that go? it's been 17 months... it must've been done by now?

## interesting links

[badass writeup article by arcadeblogger.com](https://arcadeblogger.com/2017/11/10/atari-kangaroo-the-elephant-in-the-arcade/)

[Atari Coin Op: Kangaroo Dealer Promo (1982)](https://www.youtube.com/watch?v=LtlsqlTtYcU)

pcb pics are worthless, they were stacked boards, one on top of the other, one board was for video primarily, it had 32 chips!!

pinout thingy from here [https://www.arcade-museum.com/pinouts-game/8275.html](https://www.arcade-museum.com/pinouts-game/8275.html)

```
Kangaroo, Atari

   Solder Side       Parts Side
   ---------------------------------
           GND   1   GND
     2. Start    2   1P.Start
                 3   Coin
         Table   4   
      1P.Right   5   
    1P.Up/Jump   6   1P.Left
      1P.Punch   7   1P.Down
                 8
      2P.Right   9   
   2P.Up/Jump   10   2P.Left
     2P.Punch   11   2P.Down
                13
                14
                15
                16
                17
                18
                19   Sound Out
                20
                21
          GND   22   GND
         Sync   23   Green
          Red   24   Blue
          +5V   25   +5V
          +5V   26   +5V
         +12V   27   +12V
          -5V   28   -5V

====================================================================================== 
Kangaroo
-------- 
                 PARTS   |   SOLDER                        PARTS    |    SOLDER
       ------------------+---------------------        -------------+---------------
           1P.Start  | 1 | A |   2P.Start                       | 1 | A |  Red
                     | 2 | B |   Coin                           | 2 | B |  Green
                     | 3 | C |   GND Table                      | 3 | C |  Blue
                     | 4 | D |   1P.Right                       | 4 | D |  Sync
            1P.Left  | 5 | E |   1P.Up                          | 5 | E |  GND
            1P.Down  | 6 | F |   1P.Box                         | 6 | F |  GND
         1P.Up/Jump  | 7 | G |                                  | 7 | G |  GND
               Test  | 8 | H |   2P.Right                       | 8 | H |  +5V
            2P.Left  | 9 | I |   2P.Up                          | 9 | I |  +12V
            2P.Down  |10 | J |   2P.Box                         |10 | J |  -5V
                     |11 | K |   
                     |12 | L |   
                     |13 | M |   
                     |14 | N |   
                     |15 | O |   Sound Out
                     |16 | P |   
                GND  |17 | Q |   GND
                GND  |18 | R |   GND
                GND  |19 | S |   GND
                +5V  |20 | T |   +5V
                +5V  |21 | U |   +5V
               +12V  |22 | V |   +12V
```

arcade-museum funny writeup:

```
Game Play
Mama Kangaroo must save Kid Kangaroo from an entire gang of nasty monkeys. She must climb up ladders, jump onto platforms, leap across gaps and so on to rescue him.

The monkeys will oppose her by throwing apples at her, either overhand or underhand. If they throw apples at her underhand, Mama Kangaroo must jump over them, but if they throw them overhand, she must duck. The monkeys will also drop apple cores and Mama Kangaroo must either avoid them or punch them to score points. Mama Kangaroo can also collect fruits and vegetables including strawberries, pineapples, cherries, tomatoes, etc. to score points. Mama Kangaroo can also ring a bell to make more fruits and vegetables appear.

Whenever Mama Kangaroo is close to a monkey, she can punch the monkey and knock him out. There is also a boxing gorilla called Big Ape who will occasionally appear on some levels and will try to deprive Mama Kangaroo of her boxing gloves and leave her defenseless, but she can punch Big Ape to knock him off the screen. If Mama Kangaroo is disarmed of her gloves, she must reach Kid Kangaroo before the dangers increase.

There are four different levels. The first level just has three floors connected to three long ladders. The second level is the same as the first except that on each floor, there are platforms that Mama Kangaroo must jump onto to get to each short ladder on each floor. On the third level, the cage in which Kid Kangaroo is imprisoned is held up by an entire stack of monkeys and there is an entire horde of apples that the monkey will unleash if five of them climb up there. On this level, Mama Kangaroo must punch each monkey in the stack several times until the cage is lowered and when the cage has been lowered enough, Mama Kangaroo must climb to the next floor to get to Kid Kangaroo before the cage is raised again or before the monkeys have the horde of apple cores unleashed. On the fourth level, there are odd connections of floors, platforms and ladders and the monkeys will throw apples and drop apple cores more unpredictably.

On each level, Mama Kangaroo must rescue Kid Kangaroo in order to proceed to the next. Everytime Kid Kangaroo is rescued, he says "MOM" while "Oh! Susanna" plays. After all four levels are completed, the game starts over again and with increased difficulty.

Jumping is kind of tough in this game because you have to make a quick direction change. The game play would be improved if a jump button had been added to the original control panel. The graphics in this game have a lot of glitches.
```
